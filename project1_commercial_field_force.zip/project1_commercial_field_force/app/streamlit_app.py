"""Streamlit dashboard - Commercial & Field Force Analytics.
Personal/Academic Project | SYNTHETIC DATA.   Run:  streamlit run app/streamlit_app.py"""
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from analytics import hcp_scorecard, load_data, response_model  # noqa: E402

st.set_page_config(page_title="Field Force Analytics", page_icon="📊", layout="wide")
st.title("📊 Commercial & Field Force Analytics")
st.caption("Personal/Academic Project • 100% synthetic data • Jan–Oct 2026")


@st.cache_data
def get_data():
    return load_data()


df = get_data()

# ---------------- Sidebar filters ----------------
st.sidebar.header("Filters")
regions = st.sidebar.multiselect("Region", sorted(df.region.unique()), default=sorted(df.region.unique()))
terrs = st.sidebar.multiselect("Territory", sorted(df[df.region.isin(regions)].territory.unique()))
specs = st.sidebar.multiselect("Specialty", sorted(df.specialty.unique()))
prods = st.sidebar.multiselect("Product", sorted(df["product"].unique()))
months = sorted(df.month.unique())
m_from, m_to = st.sidebar.select_slider("Month range", options=months, value=(months[0], months[-1]))

f = df[df.region.isin(regions) & df.month.between(m_from, m_to)]
if terrs: f = f[f.territory.isin(terrs)]
if specs: f = f[f.specialty.isin(specs)]
if prods: f = f[f["product"].isin(prods)]
if f.empty:
    st.warning("No data for the selected filters."); st.stop()

# ---------------- KPI cards ----------------
tot = f.sales.sum()
c = st.columns(5)
c[0].metric("Sales (INR Cr)", f"{tot / 1e7:,.1f}")
c[1].metric("Calls", f"{f.calls.sum():,}")
c[2].metric("Sales / call (INR)", f"{tot / max(f.calls.sum(), 1):,.0f}")
c[3].metric("Avg engagement", f"{f.engagement_score.mean():.1f}")
c[4].metric("Active HCPs", f"{f.hcp_id.nunique():,}")

tab1, tab2, tab3, tab4 = st.tabs(["Trend", "Territory & Specialty", "Drivers", "Next-best-action"])

with tab1:
    t = f.groupby(["month", "product"], as_index=False).sales.sum()
    st.plotly_chart(px.line(t, x="month", y="sales", color="product", markers=True,
                            title="Monthly sales by product (INR)"), width="stretch")
    mt = f.groupby("month", as_index=False).sales.sum()
    mt["MoM %"] = mt.sales.pct_change() * 100
    st.dataframe(mt.round(1), width="stretch", hide_index=True)

with tab2:
    a, b = st.columns(2)
    ter = f.groupby("territory", as_index=False).agg(sales=("sales", "sum"), calls=("calls", "sum"))
    ter["sales_per_call"] = ter.sales / ter.calls
    a.plotly_chart(px.bar(ter.sort_values("sales"), x="sales", y="territory", orientation="h",
                          title="Sales by territory (INR)"), width="stretch")
    b.plotly_chart(px.scatter(ter, x="calls", y="sales", size="sales_per_call", text="territory",
                              title="Effort vs outcome (bubble = sales/call)"), width="stretch")
    sp = f.groupby(["specialty", "product"], as_index=False).sales.sum()
    st.plotly_chart(px.bar(sp, x="specialty", y="sales", color="product", title="Specialty × product mix"),
                    width="stretch")

with tab3:
    f2 = f.assign(eng_band=pd.cut(f.engagement_score, [0, 40, 55, 70, 100], labels=["<40", "40-55", "55-70", "70+"]))
    g = f2.groupby("eng_band", observed=True, as_index=False).agg(avg_sales=("sales", "mean"), avg_calls=("calls", "mean"))
    a, b = st.columns(2)
    a.plotly_chart(px.bar(g, x="eng_band", y="avg_sales", title="Avg sales by engagement band"), width="stretch")
    cs = f.groupby("calls", as_index=False).sales.mean()
    b.plotly_chart(px.line(cs, x="calls", y="sales", markers=True, title="Avg sales by calls/month (diminishing returns)"),
                   width="stretch")
    rm = response_model(df)
    st.markdown(
        f"**Controlled model (within-HCP, all data):** 2→3 calls ≈ **+{rm['calls_2_to_3_pct']:.1f}%** sales, "
        f"5→6 calls ≈ **+{rm['calls_5_to_6_pct']:.1f}%**; +10 engagement pts ≈ **+{rm['eng_plus10_pct']:.1f}%**; "
        f"+1 digital touchpoint ≈ **+{rm['digital_plus1_pct']:.1f}%**. _Association, not proof of causation._")

with tab4:
    sc = hcp_scorecard(f)
    pick = st.multiselect("Filter action", sorted(sc.next_best_action.unique()))
    view = sc[sc.next_best_action.isin(pick)] if pick else sc
    summ = sc.groupby("next_best_action").agg(hcps=("hcp_id", "count"), sales_cr=("total_sales", lambda s: s.sum() / 1e7)).reset_index()
    st.dataframe(summ.round(1), hide_index=True, width="stretch")
    st.dataframe(view[["hcp_id", "territory", "specialty", "total_sales", "growth_pct", "avg_engagement",
                       "total_calls", "next_best_action"]].round(1), hide_index=True, width="stretch")
    st.download_button("⬇ Download action list (CSV)", view.to_csv(index=False), "next_best_actions.csv", "text/csv")

-- Personal/Academic Project | SYNTHETIC DATA | SQLite dialect
DROP TABLE IF EXISTS fact_field_force;
DROP TABLE IF EXISTS dim_territory;

CREATE TABLE dim_territory (
    territory TEXT PRIMARY KEY,
    region    TEXT NOT NULL CHECK (region IN ('North','South','East','West'))
);

CREATE TABLE fact_field_force (
    row_id              INTEGER PRIMARY KEY AUTOINCREMENT,
    territory           TEXT    NOT NULL REFERENCES dim_territory(territory),
    hcp_id              TEXT    NOT NULL,
    specialty           TEXT    NOT NULL,
    product             TEXT    NOT NULL,
    month               TEXT    NOT NULL,            -- 'YYYY-MM'
    sales               INTEGER NOT NULL CHECK (sales >= 0),      -- INR
    calls               INTEGER NOT NULL CHECK (calls >= 0),
    engagement_score    REAL    CHECK (engagement_score BETWEEN 0 AND 100),
    digital_touchpoints INTEGER NOT NULL CHECK (digital_touchpoints >= 0)
);

CREATE INDEX idx_ff_territory ON fact_field_force(territory);
CREATE INDEX idx_ff_hcp       ON fact_field_force(hcp_id);
CREATE INDEX idx_ff_month     ON fact_field_force(month);

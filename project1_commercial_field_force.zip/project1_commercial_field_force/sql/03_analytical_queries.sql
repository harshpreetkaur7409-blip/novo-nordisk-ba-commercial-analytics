-- Personal/Academic Project | SYNTHETIC DATA | 10 analytical queries (SQLite 3.25+ for window functions)
-- Each query starts with a "-- Qn" header so src/load_sqlite.py can run and export them.

-- Q1 Product KPI summary (sales, share, call productivity, engagement)
SELECT product,
       ROUND(SUM(sales) / 1e7, 2)                                   AS sales_cr,
       ROUND(100.0 * SUM(sales) / (SELECT SUM(sales) FROM fact_field_force), 1) AS share_pct,
       SUM(calls)                                                    AS calls,
       ROUND(1.0 * SUM(sales) / NULLIF(SUM(calls), 0), 0)            AS sales_per_call,
       ROUND(AVG(engagement_score), 1)                               AS avg_engagement,
       SUM(digital_touchpoints)                                      AS digital_touchpoints
FROM fact_field_force
GROUP BY product
ORDER BY sales_cr DESC;

-- Q2 Monthly sales trend with MoM growth and 3-month moving average
WITH m AS (
    SELECT month, SUM(sales) AS s FROM fact_field_force GROUP BY month
)
SELECT month,
       s AS sales,
       ROUND(100.0 * (s - LAG(s) OVER (ORDER BY month)) / LAG(s) OVER (ORDER BY month), 1) AS mom_pct,
       ROUND(AVG(s) OVER (ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW), 0)      AS ma_3m
FROM m
ORDER BY month;

-- Q3 Territory ranking with share and cumulative share
WITH t AS (
    SELECT f.territory, d.region, SUM(f.sales) AS s
    FROM fact_field_force f JOIN dim_territory d USING (territory)
    GROUP BY f.territory, d.region
)
SELECT RANK() OVER (ORDER BY s DESC) AS rnk, territory, region, s AS sales,
       ROUND(100.0 * s / SUM(s) OVER (), 1) AS share_pct,
       ROUND(100.0 * SUM(s) OVER (ORDER BY s DESC) / SUM(s) OVER (), 1) AS cum_share_pct
FROM t
ORDER BY rnk;

-- Q4 Region x product sales matrix (CASE pivot)
SELECT d.region,
       SUM(CASE WHEN f.product = 'Basal Insulin'     THEN f.sales END) AS basal_insulin,
       SUM(CASE WHEN f.product = 'Premix Insulin'    THEN f.sales END) AS premix_insulin,
       SUM(CASE WHEN f.product = 'GLP-1 Weekly'      THEN f.sales END) AS glp1_weekly,
       SUM(CASE WHEN f.product = 'Oral Antidiabetic' THEN f.sales END) AS oral_antidiabetic,
       SUM(f.sales) AS total_sales
FROM fact_field_force f JOIN dim_territory d USING (territory)
GROUP BY d.region
ORDER BY total_sales DESC;

-- Q5 Call productivity by territory vs company average (quadrant flag)
WITH t AS (
    SELECT territory, SUM(sales) AS s, SUM(calls) AS c, COUNT(DISTINCT hcp_id) AS hcps
    FROM fact_field_force GROUP BY territory
), avg_all AS (
    SELECT 1.0 * SUM(sales) / SUM(calls) AS spc FROM fact_field_force
)
SELECT t.territory, t.hcps, t.c AS calls,
       ROUND(1.0 * t.s / t.c, 0) AS sales_per_call,
       ROUND(1.0 * t.c / t.hcps, 1) AS calls_per_hcp,
       CASE WHEN 1.0 * t.s / t.c >= a.spc THEN 'Above avg productivity' ELSE 'Below avg productivity' END AS flag
FROM t, avg_all a
ORDER BY sales_per_call DESC;

-- Q6 Specialty x product mix (% of specialty sales)
SELECT specialty, product,
       SUM(sales) AS sales,
       ROUND(100.0 * SUM(sales) / SUM(SUM(sales)) OVER (PARTITION BY specialty), 1) AS pct_of_specialty
FROM fact_field_force
GROUP BY specialty, product
ORDER BY specialty, sales DESC;

-- Q7 Pareto: HCP deciles by sales (how concentrated is the business?)
WITH h AS (
    SELECT hcp_id, SUM(sales) AS s FROM fact_field_force GROUP BY hcp_id
), d AS (
    SELECT hcp_id, s, NTILE(10) OVER (ORDER BY s DESC) AS decile FROM h
)
SELECT decile, COUNT(*) AS hcps, SUM(s) AS sales,
       ROUND(100.0 * SUM(s) / (SELECT SUM(s) FROM h), 1) AS share_pct,
       ROUND(100.0 * SUM(SUM(s)) OVER (ORDER BY decile) / (SELECT SUM(s) FROM h), 1) AS cum_share_pct
FROM d
GROUP BY decile
ORDER BY decile;

-- Q8 Engagement band vs sales and calls
SELECT CASE WHEN engagement_score < 40 THEN '1 Low (<40)'
            WHEN engagement_score < 55 THEN '2 Medium (40-55)'
            WHEN engagement_score < 70 THEN '3 High (55-70)'
            ELSE '4 Very high (70+)' END AS engagement_band,
       COUNT(*) AS hcp_product_months,
       ROUND(AVG(sales), 0) AS avg_sales,
       ROUND(AVG(calls), 2) AS avg_calls
FROM fact_field_force
GROUP BY engagement_band
ORDER BY engagement_band;

-- Q9 Digital touchpoints vs sales per HCP-product-month
SELECT CASE WHEN digital_touchpoints = 0 THEN '0'
            WHEN digital_touchpoints <= 2 THEN '1-2'
            WHEN digital_touchpoints <= 5 THEN '3-5'
            ELSE '6+' END AS digital_bucket,
       COUNT(*) AS n,
       ROUND(AVG(sales), 0) AS avg_sales,
       ROUND(AVG(engagement_score), 1) AS avg_engagement
FROM fact_field_force
GROUP BY digital_bucket
ORDER BY MIN(digital_touchpoints);

-- Q10 Declining HCPs: last 3 months vs previous 3 months (top 25 by revenue at risk)
WITH h AS (
    SELECT hcp_id, territory, specialty,
           SUM(CASE WHEN month BETWEEN '2026-08' AND '2026-10' THEN sales END) AS last3,
           SUM(CASE WHEN month BETWEEN '2026-05' AND '2026-07' THEN sales END) AS prev3,
           SUM(CASE WHEN month BETWEEN '2026-08' AND '2026-10' THEN calls END) AS calls_last3,
           SUM(CASE WHEN month BETWEEN '2026-05' AND '2026-07' THEN calls END) AS calls_prev3
    FROM fact_field_force
    GROUP BY hcp_id, territory, specialty
)
SELECT hcp_id, territory, specialty, prev3, last3,
       ROUND(100.0 * (last3 - prev3) / prev3, 1) AS pct_change,
       prev3 - last3 AS revenue_at_risk,
       calls_prev3, calls_last3
FROM h
WHERE prev3 > 0 AND 1.0 * (last3 - prev3) / prev3 < -0.15
ORDER BY revenue_at_risk DESC
LIMIT 25;

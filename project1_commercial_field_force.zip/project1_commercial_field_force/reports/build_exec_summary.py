"""Generates the 1-page executive summary (Markdown) with numbers pulled live from the data.
Personal/Academic Project | SYNTHETIC DATA.   Run: python reports/build_exec_summary.py"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from analytics import ROOT, hcp_scorecard, load_data, response_model  # noqa: E402

df = load_data()
sc = hcp_scorecard(df)
rm = response_model(df)

monthly = df.groupby("month").sales.sum()
tot_cr = df.sales.sum() / 1e7
g_total = (monthly.iloc[-1] / monthly.iloc[0] - 1) * 100
prod = df.groupby("product").sales.sum().sort_values(ascending=False)
prod_share = prod / prod.sum() * 100
pm = df.pivot_table(index="month", columns="product", values="sales", aggfunc="sum")
pg = ((pm.iloc[-1] / pm.iloc[0]) ** (1 / (len(pm) - 1)) - 1) * 100
terr = df.groupby("territory").agg(s=("sales", "sum"), c=("calls", "sum"))
terr["spc"] = terr.s / terr.c
top5_share = terr.s.nlargest(5).sum() / terr.s.sum() * 100
best, worst = terr.spc.idxmax(), terr.spc.idxmin()
top20 = sc.total_sales.head(int(len(sc) * 0.2)).sum() / sc.total_sales.sum() * 100
rescue = sc[sc.next_best_action.str.startswith(("1.", "2."))]
at_risk_cr = (rescue.sales_p3 - rescue.sales_l3).clip(lower=0).sum() / 1e7
counts = sc.next_best_action.value_counts().sort_index()
cnt = lambda p: int(counts[[i for i in counts.index if i.startswith(p)]].sum())
low_eff = sc[sc.next_best_action.str.startswith("6.")]

md = f"""# Executive Summary - Commercial & Field Force Performance (Jan-Oct 2026)
*Personal/Academic Project - built on 100% synthetic data; figures are illustrative, not real company performance.*

## Headline
Sales reached **INR {tot_cr:,.1f} Cr** across 500 HCPs and 20 territories. Monthly sales grew **{g_total:.1f}%** from Jan to Oct, led by **{prod.index[0]}** ({prod_share.iloc[0]:.0f}% of sales, {pg[prod.index[0]]:+.1f}% monthly growth). **{prod.index[-1] if pg.idxmin()==prod.index[-1] else pg.idxmin()}** is the only product with falling momentum ({pg.min():+.1f}%/month).

## What the data says
| # | Insight | Evidence |
|---|---------|----------|
| 1 | Business is concentrated | Top 20% of HCPs = **{top20:.0f}%** of sales; top 5 territories = **{top5_share:.0f}%** |
| 2 | Calls help, with diminishing returns | Controlling for HCP potential: 2nd to 3rd call = **+{rm['calls_2_to_3_pct']:.1f}%** sales vs 5th to 6th = **+{rm['calls_5_to_6_pct']:.1f}%** |
| 3 | Engagement and digital add on top of calls | +10 engagement points = **+{rm['eng_plus10_pct']:.1f}%**; +1 digital touchpoint = **+{rm['digital_plus1_pct']:.1f}%** |
| 4 | Field productivity varies widely | Sales per call: best **{best}** INR {terr.spc.max():,.0f} vs lowest **{worst}** INR {terr.spc.min():,.0f} |
| 5 | Revenue leakage is identifiable | **{len(rescue)} HCPs** fell >15% (last 3 vs prior 3 months) - about **INR {at_risk_cr:.1f} Cr** per quarter at risk |

## Next-best actions (rule-based, HCP-level list in `outputs/hcp_next_best_actions.csv`)
1. **Rescue {len(rescue)} declining HCPs** - restore call frequency where reps pulled back; add medical/KAM involvement where calls were stable. *KPI: recover 50% of the lost run-rate in 1 quarter.*
2. **Protect {cnt('3.')} key accounts** (top-quintile sales) with a named account plan and scientific engagement. *KPI: zero unplanned decline.*
3. **Activate digital for {cnt('4.')} highly engaged but digitally quiet HCPs** - webinar / e-detailing invites. *KPI: digital touchpoints per HCP, engagement score.*
4. **Re-engage {cnt('5.')} low-engagement HCPs receiving above-median calls** - switch channel or message instead of adding calls. *KPI: engagement score +5 points.*
5. **Reallocate effort from {len(low_eff)} low-return-per-call, above-median-call HCPs** to higher-response accounts (use the diminishing-returns curve). *KPI: sales per call.*

## Caveats
Synthetic data; response model shows association (within-HCP, R2 = {rm['within_r2']:.2f}), not proven causation - validate with a field pilot (test vs control territories) before scaling. NBA thresholds are editable in `src/analytics.py`.
"""
out = ROOT / "reports" / "executive_summary.md"
out.write_text(md, encoding="utf-8")
print(md)

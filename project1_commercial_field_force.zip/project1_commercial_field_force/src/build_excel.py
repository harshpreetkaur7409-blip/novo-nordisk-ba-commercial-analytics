"""Build the Excel workbook: Data table, formula-driven pivot-style sheets, HCP scorecard + KPI dashboard.
Personal/Academic Project | SYNTHETIC DATA.   Run: python src/build_excel.py   (then recalc if using LibreOffice)"""
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.worksheet.table import Table, TableStyleInfo

from analytics import ROOT, hcp_scorecard, load_data

NAVY, LIGHT = "001965", "DCE6F5"
F = lambda **k: Font(name="Arial", size=k.pop("size", 10), **k)
HDR_FILL = PatternFill("solid", fgColor=NAVY)
thin = Side(style="thin", color="BFBFBF")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)


def header(ws, row, cols, start=1):
    for i, c in enumerate(cols):
        cell = ws.cell(row=row, column=start + i, value=c)
        cell.font, cell.fill = F(bold=True, color="FFFFFF"), HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER


def widths(ws, w):
    for i, x in enumerate(w, 1):
        ws.column_dimensions[get_column_letter(i)].width = x


def main():
    df = load_data()
    sc = hcp_scorecard(df)
    n = len(df)
    last = n + 1
    months = sorted(df["month_dt"].unique())
    products = ["Basal Insulin", "Premix Insulin", "GLP-1 Weekly", "Oral Antidiabetic"]
    R = lambda col: f"Data!${col}$2:${col}${last}"           # absolute data ranges
    TERR, SPEC, PROD, MON, SAL, CAL, ENG, DIG = (R(c) for c in "ACDEFGHI")
    # NOTE: Data column order = A territory, B hcp_id, C specialty, D product, E month, F sales, G calls, H engagement, I digital
    TERR, SPEC, PROD, MON, SAL, CAL, ENG, DIG = R("A"), R("C"), R("D"), R("E"), R("F"), R("G"), R("H"), R("I")

    wb = Workbook()

    # ---------------- README ----------------
    ws = wb.active; ws.title = "README"
    notes = [
        ("Commercial & Field Force Analytics - Excel workbook", True),
        ("Personal/Academic Project | 100% SYNTHETIC data (no real patient, HCP or company data)", True),
        ("", False),
        ("Sheets", True),
        ("Data - 10,000 rows (also an Excel Table named tblData: select it > Insert > PivotTable for native pivots).", False),
        ("Pivot_Product_Month, Pivot_Territory, Pivot_Specialty - pivot-style summaries built with live SUMIFS/AVERAGEIFS formulas.", False),
        ("HCP_Scorecard - one row per HCP, computed in Python (src/analytics.py); NBA rules documented there.", False),
        ("KPI_Dashboard - headline KPIs, charts, NBA summary. Change the yellow month cell to update monthly KPIs.", False),
        ("", False),
        ("Conventions: blue text = input/hardcoded, black = formula. Sales are in INR; dashboard shows INR Crore (1 Cr = 10,000,000).", False),
        ("Why not native PivotTables? Python (openpyxl) cannot author PivotTable objects; formula-based grids refresh automatically and are transparent.", False),
    ]
    for i, (t, b) in enumerate(notes, 1):
        ws.cell(row=i, column=1, value=t).font = F(bold=b, size=12 if i == 1 else 10)
    ws.column_dimensions["A"].width = 130

    # ---------------- Data ----------------
    wd = wb.create_sheet("Data")
    cols = ["territory", "hcp_id", "specialty", "product", "month", "sales", "calls", "engagement_score", "digital_touchpoints"]
    header(wd, 1, cols)
    for r in df.itertuples():
        wd.append([r.territory, r.hcp_id, r.specialty, r.product, r.month_dt.to_pydatetime(),
                   r.sales, r.calls, r.engagement_score, r.digital_touchpoints])
    for row in wd.iter_rows(min_row=2, max_row=last):
        row[4].number_format = "mmm-yy"
        row[5].number_format = "#,##0"
        for c in row: c.font = F(color="0000FF")             # hardcoded source data = blue
    tab = Table(displayName="tblData", ref=f"A1:I{last}")
    tab.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
    wd.add_table(tab); wd.freeze_panes = "A2"; widths(wd, [16, 10, 22, 18, 10, 12, 8, 16, 18])

    # ---------------- Pivot_Product_Month ----------------
    wp = wb.create_sheet("Pivot_Product_Month")
    header(wp, 1, ["Month"] + products + ["Total", "MoM %"])
    for i, m in enumerate(months, 2):
        c = wp.cell(row=i, column=1, value=m.to_pydatetime()); c.number_format = "mmm-yy"; c.font = F(color="0000FF")
        for j in range(len(products)):
            col = get_column_letter(2 + j)
            wp.cell(row=i, column=2 + j, value=f"=SUMIFS({SAL},{MON},$A{i},{PROD},{col}$1)").number_format = "#,##0"
        wp.cell(row=i, column=6, value=f"=SUM(B{i}:E{i})").number_format = "#,##0"
        if i > 2:
            wp.cell(row=i, column=7, value=f"=IFERROR(F{i}/F{i-1}-1,0)").number_format = "0.0%"
    tr = len(months) + 2
    wp.cell(row=tr, column=1, value="Total").font = F(bold=True)
    for j in range(2, 7):
        col = get_column_letter(j)
        c = wp.cell(row=tr, column=j, value=f"=SUM({col}2:{col}{tr-1})"); c.number_format = "#,##0"; c.font = F(bold=True)
    wp.cell(row=tr + 2, column=1, value="Sales in INR. Pivot-style grid: SUMIFS over Data sheet.").font = F(italic=True)
    widths(wp, [12, 16, 16, 16, 18, 16, 10])
    for row in wp.iter_rows(min_row=2, max_row=tr):
        for c in row:
            c.font = F(bold=c.font.bold, color=c.font.color) if c.font else F()

    # ---------------- Pivot_Territory ----------------
    wt = wb.create_sheet("Pivot_Territory")
    header(wt, 1, ["Territory", "Region"] + products + ["Total sales", "Share %", "Rank", "Calls", "Sales per call"])
    terr = (df.groupby("territory")["sales"].sum().sort_values(ascending=False).index.tolist())
    reg = df.drop_duplicates("territory").set_index("territory")["region"]
    for i, t in enumerate(terr, 2):
        wt.cell(row=i, column=1, value=t).font = F(color="0000FF")
        wt.cell(row=i, column=2, value=reg[t]).font = F(color="0000FF")
        for j in range(len(products)):
            col = get_column_letter(3 + j)
            wt.cell(row=i, column=3 + j, value=f"=SUMIFS({SAL},{TERR},$A{i},{PROD},{col}$1)").number_format = "#,##0"
        wt.cell(row=i, column=7, value=f"=SUM(C{i}:F{i})").number_format = "#,##0"
        wt.cell(row=i, column=8, value=f"=G{i}/$G${len(terr)+2}").number_format = "0.0%"
        wt.cell(row=i, column=9, value=f"=RANK(G{i},$G$2:$G${len(terr)+1})")
        wt.cell(row=i, column=10, value=f"=SUMIFS({CAL},{TERR},$A{i})").number_format = "#,##0"
        wt.cell(row=i, column=11, value=f"=IFERROR(G{i}/J{i},0)").number_format = "#,##0"
    te = len(terr) + 2
    wt.cell(row=te, column=1, value="Total").font = F(bold=True)
    for j in [3, 4, 5, 6, 7, 10]:
        col = get_column_letter(j)
        c = wt.cell(row=te, column=j, value=f"=SUM({col}2:{col}{te-1})"); c.number_format = "#,##0"; c.font = F(bold=True)
    wt.cell(row=te, column=11, value=f"=IFERROR(G{te}/J{te},0)").number_format = "#,##0"
    widths(wt, [16, 9, 15, 15, 15, 17, 16, 9, 7, 9, 14])

    # ---------------- Pivot_Specialty ----------------
    wsx = wb.create_sheet("Pivot_Specialty")
    header(wsx, 1, ["Specialty", "Sales (INR)", "Calls", "Sales per call", "Avg engagement", "Digital touchpoints"])
    specs = df.groupby("specialty")["sales"].sum().sort_values(ascending=False).index.tolist()
    for i, s in enumerate(specs, 2):
        wsx.cell(row=i, column=1, value=s).font = F(color="0000FF")
        wsx.cell(row=i, column=2, value=f"=SUMIFS({SAL},{SPEC},$A{i})").number_format = "#,##0"
        wsx.cell(row=i, column=3, value=f"=SUMIFS({CAL},{SPEC},$A{i})").number_format = "#,##0"
        wsx.cell(row=i, column=4, value=f"=IFERROR(B{i}/C{i},0)").number_format = "#,##0"
        wsx.cell(row=i, column=5, value=f"=AVERAGEIFS({ENG},{SPEC},$A{i})").number_format = "0.0"
        wsx.cell(row=i, column=6, value=f"=SUMIFS({DIG},{SPEC},$A{i})").number_format = "#,##0"
    widths(wsx, [24, 16, 10, 14, 16, 18])

    # ---------------- HCP_Scorecard ----------------
    wh = wb.create_sheet("HCP_Scorecard")
    sc_cols = ["hcp_id", "territory", "specialty", "total_sales", "total_calls", "avg_engagement",
               "digital_touchpoints", "sales_l3", "sales_p3", "growth_pct", "sales_per_call", "next_best_action"]
    header(wh, 1, sc_cols)
    for r in sc[sc_cols].itertuples(index=False):
        wh.append([*r[:3], *[float(x) for x in r[3:11]], r[11]])
    for row in wh.iter_rows(min_row=2, max_row=len(sc) + 1):
        for k in (3, 7, 8, 10): row[k].number_format = "#,##0"
        row[5].number_format = "0.0"; row[9].number_format = "0.0"
        for c in row: c.font = F(color="0000FF")      # Python-computed values pasted in = blue
    wh.freeze_panes = "A2"; widths(wh, [10, 16, 22, 14, 11, 13, 13, 14, 14, 11, 14, 52])
    wh.auto_filter.ref = f"A1:L{len(sc)+1}"
    sl = len(sc) + 1

    # ---------------- KPI_Dashboard ----------------
    wk = wb.create_sheet("KPI_Dashboard", 1)
    wk.sheet_view.showGridLines = False
    wk["B1"] = "Commercial & Field Force KPI Dashboard"; wk["B1"].font = F(bold=True, size=16, color=NAVY)
    wk["B2"] = "Personal/Academic Project | Synthetic data | Jan-Oct 2026"; wk["B2"].font = F(italic=True, color="7F7F7F")
    wk["B4"] = "Select month (input)"; wk["B4"].font = F(bold=True)
    wk["C4"] = months[-1].to_pydatetime(); wk["C4"].number_format = "mmm-yy"
    wk["C4"].font = F(color="0000FF", bold=True); wk["C4"].fill = PatternFill("solid", fgColor="FFFF00")
    dv = DataValidation(type="list", formula1=f"=Pivot_Product_Month!$A$2:$A${len(months)+1}", allow_blank=False)
    wk.add_data_validation(dv); dv.add("C4")
    pm_rng = f"Pivot_Product_Month!$A$2:$A${len(months)+1}"
    pm_tot = f"Pivot_Product_Month!$F$2:$F${len(months)+1}"
    kpis = [
        ("Total sales YTD (INR Cr)", f"=SUM({SAL})/10000000", "#,##0.0"),
        ("Selected-month sales (INR Cr)", f"=SUMIFS({SAL},{MON},$C$4)/10000000", "#,##0.00"),
        ("MoM growth (selected month)", f"=IFERROR(INDEX({pm_tot},MATCH($C$4,{pm_rng},0))/INDEX({pm_tot},MATCH($C$4,{pm_rng},0)-1)-1,0)", "0.0%"),
        ("Total calls", f"=SUM({CAL})", "#,##0"),
        ("Sales per call (INR)", f"=SUM({SAL})/SUM({CAL})", "#,##0"),
        ("Average engagement score", f"=AVERAGE({ENG})", "0.0"),
        ("Digital touchpoints", f"=SUM({DIG})", "#,##0"),
        ("Active HCPs", f"=COUNTA(HCP_Scorecard!$A$2:$A${sl})", "#,##0"),
        ("Top-20% HCP share of sales", f"=SUMPRODUCT((HCP_Scorecard!$D$2:$D${sl}>=PERCENTILE(HCP_Scorecard!$D$2:$D${sl},0.8))*HCP_Scorecard!$D$2:$D${sl})/SUM(HCP_Scorecard!$D$2:$D${sl})", "0.0%"),
    ]
    header(wk, 6, ["KPI", "Value"], start=2)
    for i, (lab, fm, nf) in enumerate(kpis, 7):
        wk.cell(row=i, column=2, value=lab).font = F(); wk.cell(row=i, column=2).border = BORDER
        c = wk.cell(row=i, column=3, value=fm); c.number_format = nf; c.font = F(bold=True); c.border = BORDER
        c.alignment = Alignment(horizontal="right")
    r0 = 7 + len(kpis) + 1
    wk.cell(row=r0, column=2, value="Next-best-action summary").font = F(bold=True, color=NAVY, size=12)
    header(wk, r0 + 1, ["Action", "HCPs", "Sales (INR Cr)"], start=2)
    actions = sorted(sc["next_best_action"].unique())
    for i, a in enumerate(actions, r0 + 2):
        wk.cell(row=i, column=2, value=a).font = F(color="0000FF")
        wk.cell(row=i, column=3, value=f"=COUNTIF(HCP_Scorecard!$L$2:$L${sl},B{i})")
        wk.cell(row=i, column=4, value=f"=SUMIFS(HCP_Scorecard!$D$2:$D${sl},HCP_Scorecard!$L$2:$L${sl},B{i})/10000000").number_format = "#,##0.0"
        for k in (2, 3, 4): wk.cell(row=i, column=k).border = BORDER
    widths(wk, [3, 52, 18, 16, 3])

    # Charts
    ch = LineChart(); ch.title = "Monthly sales by product (INR)"; ch.height, ch.width = 8, 16
    ch.add_data(Reference(wp, min_col=2, max_col=5, min_row=1, max_row=len(months) + 1), titles_from_data=True)
    ch.set_categories(Reference(wp, min_col=1, min_row=2, max_row=len(months) + 1))
    ch.x_axis.number_format = "mmm-yy"; ch.x_axis.delete = False; ch.y_axis.delete = False
    wk.add_chart(ch, "F4")
    bc = BarChart(); bc.type = "bar"; bc.title = "Sales by territory (INR)"; bc.height, bc.width = 11, 16
    bc.add_data(Reference(wt, min_col=7, min_row=1, max_row=len(terr) + 1), titles_from_data=True)
    bc.set_categories(Reference(wt, min_col=1, min_row=2, max_row=len(terr) + 1))
    bc.x_axis.scaling.orientation = "maxMin"; bc.x_axis.delete = False; bc.y_axis.delete = False; bc.legend = None
    wk.add_chart(bc, "F21")

    out = ROOT / "excel" / "Commercial_FieldForce_Dashboard.xlsx"
    out.parent.mkdir(exist_ok=True)
    wb.save(out)
    print("Saved", out)


if __name__ == "__main__":
    main()

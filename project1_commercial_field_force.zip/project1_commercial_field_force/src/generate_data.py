"""
Personal/Academic Project - Synthetic data generator.
Creates 10,000 rows of FICTIONAL commercial & field-force data
(500 HCPs x 2 products x 10 months). No real patient/HCP/company data.

Outputs:
  data/field_force_sales.csv
  sql/02_insert_data.sql   (dim_territory + fact_field_force INSERTs)
"""
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
rng = np.random.default_rng(42)          # fixed seed -> reproducible

N_HCP = 500
MONTHS = [f"2026-{m:02d}" for m in range(1, 11)]   # Jan-Oct 2026

TERRITORIES = {                           # territory -> region
    "Mumbai": "West", "Pune": "West", "Ahmedabad": "West", "Surat": "West", "Vadodara": "West",
    "Delhi NCR": "North", "Jaipur": "North", "Lucknow": "North", "Chandigarh": "North", "Patna": "North",
    "Bengaluru": "South", "Chennai": "South", "Hyderabad": "South", "Kochi": "South", "Coimbatore": "South",
    "Kolkata": "East", "Bhubaneswar": "East", "Visakhapatnam": "East", "Indore": "West", "Nagpur": "West",
}
SPECIALTIES = ["Diabetologist", "Endocrinologist", "Cardiologist",
               "Consultant Physician", "General Practitioner", "Nephrologist"]
SPEC_P = [0.22, 0.12, 0.14, 0.22, 0.24, 0.06]
SPEC_FACTOR = {"Diabetologist": 1.5, "Endocrinologist": 1.3, "Cardiologist": 0.9,
               "Consultant Physician": 1.0, "General Practitioner": 0.6, "Nephrologist": 0.7}

# Generic, fictional product labels (not real brands)
PRODUCTS = ["Basal Insulin", "Premix Insulin", "GLP-1 Weekly", "Oral Antidiabetic"]
PROD_BASE = {"Basal Insulin": 55000, "Premix Insulin": 40000, "GLP-1 Weekly": 80000, "Oral Antidiabetic": 30000}
PROD_GROWTH = {"Basal Insulin": 0.008, "Premix Insulin": -0.004, "GLP-1 Weekly": 0.025, "Oral Antidiabetic": 0.004}
PROD_PROBS = {
    "Diabetologist":        [0.30, 0.20, 0.35, 0.15],
    "Endocrinologist":      [0.28, 0.12, 0.45, 0.15],
    "Cardiologist":         [0.15, 0.10, 0.35, 0.40],
    "Consultant Physician": [0.30, 0.25, 0.15, 0.30],
    "General Practitioner": [0.25, 0.30, 0.05, 0.40],
    "Nephrologist":         [0.25, 0.10, 0.25, 0.40],
}


def main():
    # ---- HCP master -------------------------------------------------
    terr_p = rng.dirichlet(np.ones(len(TERRITORIES)) * 8)
    hcp = pd.DataFrame({"hcp_id": [f"HCP{i:04d}" for i in range(1, N_HCP + 1)]})
    hcp["territory"] = rng.choice(list(TERRITORIES), size=N_HCP, p=terr_p)
    hcp["specialty"] = rng.choice(SPECIALTIES, size=N_HCP, p=SPEC_P)
    hcp["potential"] = rng.lognormal(0, 0.55, N_HCP) * hcp["specialty"].map(SPEC_FACTOR)
    hcp["eng_aff"] = rng.normal(0, 1, N_HCP)      # latent "receptiveness"
    hcp["dig_aff"] = rng.normal(0, 1, N_HCP)      # latent digital affinity
    hcp["at_risk"] = rng.random(N_HCP) < 0.10     # ~10% HCPs drift away from month 6
    hcp["pot_rank"] = hcp["potential"].rank(pct=True)

    pairs = []
    for _, r in hcp.iterrows():                    # each HCP prescribes 2 products
        for p in rng.choice(PRODUCTS, size=2, replace=False, p=PROD_PROBS[r["specialty"]]):
            pairs.append((r["hcp_id"], p))
    df = pd.DataFrame(pairs, columns=["hcp_id", "product"]).merge(hcp, on="hcp_id")
    df = df.merge(pd.DataFrame({"month": MONTHS, "m": range(1, 11)}), how="cross")

    # ---- territory effects -----------------------------------------
    terr_factor = {t: rng.lognormal(0, 0.20) for t in TERRITORIES}
    terr_call = {t: rng.uniform(0.8, 1.25) for t in TERRITORIES}
    df["terr_f"] = df["territory"].map(terr_factor)
    df["terr_c"] = df["territory"].map(terr_call)

    # ---- activity ---------------------------------------------------
    pullback = np.where(df["at_risk"], 1 - 0.08 * np.maximum(0, df["m"] - 5), 1.0)   # reps pulled back
    lam = (1.2 + 3.5 * df["pot_rank"]) * df["terr_c"] * pullback
    df["calls"] = np.minimum(rng.poisson(lam), 12)
    eng = 45 + 6 * np.log1p(df["calls"]) + 8 * df["eng_aff"] + rng.normal(0, 7, len(df))
    df["engagement_score"] = np.clip(eng, 0, 100).round(1)
    df["digital_touchpoints"] = rng.poisson(np.exp(0.2 + 0.5 * df["dig_aff"] + 0.01 * (df["engagement_score"] - 50)))

    # ---- sales (INR) ------------------------------------------------
    season = 1 + 0.06 * np.sin(2 * np.pi * (df["m"] - 4) / 12)
    trend = (1 + df["product"].map(PROD_GROWTH)) ** (df["m"] - 1)
    decay = np.where(df["at_risk"], 1 - 0.07 * np.maximum(0, df["m"] - 5), 1.0)
    response = ((1 + 0.35 * np.log1p(df["calls"]))                # diminishing returns to calls
                * (0.75 + 0.5 * df["engagement_score"] / 100)
                * (1 + 0.04 * df["digital_touchpoints"]))
    sales = (df["potential"] * df["product"].map(PROD_BASE) * df["terr_f"] * season
             * trend * response * decay * rng.lognormal(0, 0.20, len(df)))
    df["sales"] = sales.round(0).astype(int)

    cols = ["territory", "hcp_id", "specialty", "product", "month",
            "sales", "calls", "engagement_score", "digital_touchpoints"]
    out = df[cols].sort_values(["month", "territory", "hcp_id", "product"]).reset_index(drop=True)
    assert len(out) == 10_000

    (ROOT / "data").mkdir(exist_ok=True)
    out.to_csv(ROOT / "data" / "field_force_sales.csv", index=False)

    # ---- SQL INSERT script -----------------------------------------
    lines = ["-- Personal/Academic Project | SYNTHETIC DATA | auto-generated by src/generate_data.py",
             "BEGIN TRANSACTION;"]
    lines.append("INSERT INTO dim_territory (territory, region) VALUES")
    lines.append(",\n".join(f"  ('{t}', '{r}')" for t, r in TERRITORIES.items()) + ";")
    ins = ("INSERT INTO fact_field_force (territory, hcp_id, specialty, product, month, "
           "sales, calls, engagement_score, digital_touchpoints) VALUES")
    for i in range(0, len(out), 200):
        chunk = out.iloc[i:i + 200]
        vals = ",\n".join(
            f"  ('{r.territory}','{r.hcp_id}','{r.specialty}','{r.product}','{r.month}',"
            f"{r.sales},{r.calls},{r.engagement_score},{r.digital_touchpoints})"
            for r in chunk.itertuples())
        lines.append(f"{ins}\n{vals};")
    lines.append("COMMIT;")
    (ROOT / "sql" / "02_insert_data.sql").write_text("\n".join(lines), encoding="utf-8")
    print(f"Generated {len(out):,} rows -> data/field_force_sales.csv and sql/02_insert_data.sql")


if __name__ == "__main__":
    main()

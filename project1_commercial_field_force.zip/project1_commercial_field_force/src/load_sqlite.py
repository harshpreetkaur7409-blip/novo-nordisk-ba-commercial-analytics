"""Build SQLite DB from the SQL scripts and run/export the 10 analytical queries."""
import re
import sqlite3
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "data" / "field_force.db"
OUT = ROOT / "outputs" / "sql_results"


def build_db():
    DB.unlink(missing_ok=True)
    con = sqlite3.connect(DB)
    con.executescript((ROOT / "sql" / "01_create_tables.sql").read_text(encoding="utf-8"))
    con.executescript((ROOT / "sql" / "02_insert_data.sql").read_text(encoding="utf-8"))
    n = con.execute("SELECT COUNT(*) FROM fact_field_force").fetchone()[0]
    print(f"Database built: {DB.name} | rows in fact table = {n:,}")
    return con


def run_queries(con):
    OUT.mkdir(parents=True, exist_ok=True)
    text = (ROOT / "sql" / "03_analytical_queries.sql").read_text(encoding="utf-8")
    parts = re.split(r"(?m)^-- (Q\d+[^\n]*)\n", text)
    for title, body in zip(parts[1::2], parts[2::2]):
        df = pd.read_sql_query(body.strip(), con)
        fname = title.split()[0].lower() + ".csv"
        df.to_csv(OUT / fname, index=False)
        print(f"\n=== {title} ===")
        print(df.head(8).to_string(index=False))


if __name__ == "__main__":
    connection = build_db()
    run_queries(connection)
    connection.close()

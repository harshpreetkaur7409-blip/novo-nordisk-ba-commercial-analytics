"""Shared analytics helpers used by EDA, Excel builder, dashboard and exec summary.
Personal/Academic Project | SYNTHETIC DATA."""
import numpy as np
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "field_force_sales.csv"

REGION = {
    "Mumbai": "West", "Pune": "West", "Ahmedabad": "West", "Surat": "West", "Vadodara": "West",
    "Indore": "West", "Nagpur": "West", "Delhi NCR": "North", "Jaipur": "North", "Lucknow": "North",
    "Chandigarh": "North", "Patna": "North", "Bengaluru": "South", "Chennai": "South",
    "Hyderabad": "South", "Kochi": "South", "Coimbatore": "South", "Kolkata": "East",
    "Bhubaneswar": "East", "Visakhapatnam": "East",
}

# Transparent, editable thresholds for the next-best-action (NBA) rules
RULES = {"decline_pct": -15.0, "eng_high_q": 0.70, "eng_low_q": 0.30,
         "sales_top_q": 0.80, "spc_bottom_q": 0.30}


def load_data(path=DATA) -> pd.DataFrame:
    if not Path(path).exists():                      # auto-generate if user skipped step 1
        from generate_data import main
        main()
    df = pd.read_csv(path)
    df["region"] = df["territory"].map(REGION)
    df["month_dt"] = pd.to_datetime(df["month"] + "-01")
    return df


def hcp_scorecard(df: pd.DataFrame) -> pd.DataFrame:
    """One row per HCP with performance, trend and a rule-based next-best-action."""
    months = sorted(df["month"].unique())
    last3, prev3 = months[-3:], months[-6:-3]

    base = (df.groupby(["hcp_id", "territory", "specialty"])
              .agg(total_sales=("sales", "sum"), total_calls=("calls", "sum"),
                   avg_engagement=("engagement_score", "mean"),
                   digital_touchpoints=("digital_touchpoints", "sum")).reset_index())
    l3 = df[df.month.isin(last3)].groupby("hcp_id").agg(sales_l3=("sales", "sum"), calls_l3=("calls", "sum"))
    p3 = df[df.month.isin(prev3)].groupby("hcp_id").agg(sales_p3=("sales", "sum"), calls_p3=("calls", "sum"))
    sc = base.merge(l3, on="hcp_id", how="left").merge(p3, on="hcp_id", how="left").fillna(0)
    sc["growth_pct"] = np.where(sc.sales_p3 > 0, (sc.sales_l3 / sc.sales_p3 - 1) * 100, 0.0)
    sc["sales_per_call"] = np.where(sc.total_calls > 0, sc.total_sales / sc.total_calls, 0.0)
    sc["avg_engagement"] = sc["avg_engagement"].round(1)

    q = RULES
    s_hi, spc_lo = sc.total_sales.quantile(q["sales_top_q"]), sc.sales_per_call.quantile(q["spc_bottom_q"])
    e_hi, e_lo = sc.avg_engagement.quantile(q["eng_high_q"]), sc.avg_engagement.quantile(q["eng_low_q"])
    c_med, d_med = sc.total_calls.median(), sc.digital_touchpoints.median()

    def nba(r):
        if r.growth_pct <= q["decline_pct"] and r.calls_l3 < r.calls_p3:
            return "1. Rescue: restore call frequency + senior review"
        if r.growth_pct <= q["decline_pct"]:
            return "2. Rescue: change message / involve medical team"
        if r.total_sales >= s_hi:
            return "3. Protect & grow: key-account plan"
        if r.avg_engagement >= e_hi and r.digital_touchpoints <= d_med:
            return "4. Activate digital: webinar / e-detailing invite"
        if r.avg_engagement <= e_lo and r.total_calls >= c_med:
            return "5. Re-engage: switch channel, new content"
        if r.sales_per_call <= spc_lo and r.total_calls >= c_med:
            return "6. Optimise effort: low return per call, shift to digital"
        return "7. Maintain & monitor"

    sc["next_best_action"] = sc.apply(nba, axis=1)
    return sc.sort_values("total_sales", ascending=False).reset_index(drop=True)


def response_model(df: pd.DataFrame) -> dict:
    """Within-HCP-product (fixed-effects) log-linear model of sales on call/engagement/digital.
    Controls for HCP potential and month. Association, not proof of causation."""
    d = df.copy()
    d["ln_sales"] = np.log(d["sales"].clip(lower=1))
    d["ln_calls"] = np.log1p(d["calls"])
    feats = ["ln_calls", "engagement_score", "digital_touchpoints"]
    cols = ["ln_sales"] + feats
    month_dum = pd.get_dummies(d["month"], drop_first=True).astype(float)
    work = pd.concat([d[cols], month_dum], axis=1)
    work = work - work.groupby([d["hcp_id"], d["product"]]).transform("mean")
    X, y = work.drop(columns="ln_sales").values, work["ln_sales"].values
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    r2 = 1 - ((y - X @ beta) ** 2).sum() / (y ** 2).sum()
    b_calls, b_eng, b_dig = beta[:3]
    pct = lambda x: (np.exp(x) - 1) * 100
    return {
        "within_r2": float(r2),
        "calls_2_to_3_pct": float(pct(b_calls * (np.log(4) - np.log(3)))),
        "calls_5_to_6_pct": float(pct(b_calls * (np.log(7) - np.log(6)))),
        "eng_plus10_pct": float(pct(b_eng * 10)),
        "digital_plus1_pct": float(pct(b_dig)),
    }

"""Python EDA + trend analysis + simple ML driver model. Personal/Academic Project | SYNTHETIC DATA.
Run:  python src/eda.py     -> prints findings, saves charts to reports/figures/, NBA list to outputs/"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.model_selection import train_test_split

from analytics import ROOT, hcp_scorecard, load_data, response_model

FIG = ROOT / "reports" / "figures"
FIG.mkdir(parents=True, exist_ok=True)
(ROOT / "outputs").mkdir(exist_ok=True)
sns.set_theme(style="whitegrid", context="notebook")


def save(name):
    plt.tight_layout()
    plt.savefig(FIG / name, dpi=130)
    plt.close()


def main():
    df = load_data()

    # 1. Data quality ---------------------------------------------------
    print("Shape:", df.shape)
    print("\nMissing values:\n", df.isna().sum()[df.isna().sum() > 0] if df.isna().any().any() else "none")
    print("Duplicate HCP-product-month rows:", df.duplicated(["hcp_id", "product", "month"]).sum())
    print("\nSummary stats:\n", df[["sales", "calls", "engagement_score", "digital_touchpoints"]].describe().round(1))

    # 2. Distributions ---------------------------------------------------
    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    sns.histplot(df["sales"], bins=50, ax=ax[0]); ax[0].set_title("Sales per HCP-product-month (INR) - right-skewed")
    sns.histplot(np.log10(df["sales"]), bins=50, ax=ax[1]); ax[1].set_title("log10(Sales) - closer to normal")
    sns.countplot(x="calls", data=df, ax=ax[2], color="steelblue"); ax[2].set_title("Calls per month")
    save("01_distributions.png")

    # 3. Trend analysis -------------------------------------------------
    trend = df.pivot_table(index="month_dt", columns="product", values="sales", aggfunc="sum") / 1e7
    trend.plot(figsize=(9, 4.5), marker="o"); plt.ylabel("Sales (INR Cr)"); plt.title("Monthly sales by product")
    save("02_monthly_trend.png")
    total = trend.sum(axis=1)
    print(f"\nTotal sales Jan->Oct: {total.iloc[0]:.1f} -> {total.iloc[-1]:.1f} INR Cr "
          f"({(total.iloc[-1] / total.iloc[0] - 1) * 100:.1f}% growth)")
    print("Product CAGR-style monthly growth (%):\n",
          (((trend.iloc[-1] / trend.iloc[0]) ** (1 / (len(trend) - 1)) - 1) * 100).round(2))

    # 4. Territory & specialty ------------------------------------------
    terr = df.groupby("territory").agg(sales=("sales", "sum"), calls=("calls", "sum")).assign(
        spc=lambda t: t.sales / t.calls).sort_values("sales", ascending=False)
    fig, ax = plt.subplots(1, 2, figsize=(14, 5))
    (terr["sales"] / 1e7).plot.barh(ax=ax[0], color="#001965"); ax[0].invert_yaxis(); ax[0].set_title("Sales by territory (INR Cr)")
    sns.scatterplot(data=terr, x="calls", y="sales", size="spc", ax=ax[1], legend=False)
    for t, r in terr.iterrows(): ax[1].annotate(t, (r.calls, r.sales), fontsize=7)
    ax[1].set_title("Effort vs outcome (bubble = sales per call)")
    save("03_territory.png")

    # 5. Relationships --------------------------------------------------
    num = df[["sales", "calls", "engagement_score", "digital_touchpoints"]].copy()
    num["sales"] = np.log(num["sales"])
    plt.figure(figsize=(5.5, 4.5)); sns.heatmap(num.corr(), annot=True, fmt=".2f", cmap="Blues")
    plt.title("Correlation (log sales)"); save("04_correlation.png")

    plt.figure(figsize=(7, 4.5))
    sns.pointplot(data=df, x="calls", y="sales", errorbar=("ci", 95), color="#001965")
    plt.title("Average sales by calls/month: diminishing returns"); save("05_calls_vs_sales.png")

    # 6. Pareto ---------------------------------------------------------
    sc = hcp_scorecard(df)
    cum = sc["total_sales"].cumsum() / sc["total_sales"].sum() * 100
    plt.figure(figsize=(7, 4.5)); plt.plot(np.arange(1, len(cum) + 1) / len(cum) * 100, cum)
    plt.axvline(20, ls="--", c="grey"); plt.xlabel("% of HCPs"); plt.ylabel("% of sales"); plt.title("Pareto curve")
    save("06_pareto.png")
    print(f"\nTop 20% of HCPs generate {cum.iloc[int(len(cum) * 0.2) - 1]:.1f}% of sales")

    # 7. Controlled response model ---------------------------------------
    rm = response_model(df)
    print("\nWithin-HCP response model (controls for HCP potential + month):")
    for k, v in rm.items(): print(f"  {k}: {v:.2f}")

    # 8. ML driver model (Random Forest + permutation importance) --------
    feat = pd.get_dummies(df[["product", "specialty", "region"]], drop_first=True)
    feat = pd.concat([feat, df[["calls", "engagement_score", "digital_touchpoints"]],
                      df["month_dt"].dt.month.rename("month_num")], axis=1)
    y = np.log(df["sales"])
    Xtr, Xte, ytr, yte = train_test_split(feat, y, test_size=0.25, random_state=42)
    rf = RandomForestRegressor(n_estimators=200, min_samples_leaf=5, random_state=42, n_jobs=-1).fit(Xtr, ytr)
    print(f"\nRandom Forest R2 (hold-out, log sales): {rf.score(Xte, yte):.3f}")
    pi = permutation_importance(rf, Xte, yte, n_repeats=5, random_state=42, n_jobs=-1)
    imp = pd.Series(pi.importances_mean, index=feat.columns).sort_values(ascending=False).head(10)
    imp[::-1].plot.barh(figsize=(7, 4.5), color="#001965"); plt.title("Permutation importance (top 10)")
    save("07_feature_importance.png")
    print(imp.round(3))

    # 9. Next-best-action output ----------------------------------------
    sc.to_csv(ROOT / "outputs" / "hcp_next_best_actions.csv", index=False)
    print("\nNext-best-action distribution:\n", sc["next_best_action"].value_counts().sort_index())
    print(f"\nCharts saved in {FIG}; NBA list saved to outputs/hcp_next_best_actions.csv")


if __name__ == "__main__":
    main()
